#include <ros/ros.h>
#include <geometry_msgs/Twist.h>

void twistCallback(const geometry_msgs::Twist& msg) {
    // 处理接收到的 Twist 数据
    // 可以在这里添加发送控制指令到 STM32 的代码
}

int main(int argc, char** argv) {
    ros::init(argc, argv, "twist_subscriber");
    ros::NodeHandle node;

    // 创建一个订阅器，订阅 Twist 消息
    ros::Subscriber sub = node.subscribe("cmd_vel", 1000, twistCallback);

    ros::spin(); // 始终循环等待接收 Twist 数据

    return 0;
}
