#include <ros/ros.h>
#include <tf2_ros/transform_broadcaster.h>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2/LinearMath/Transform.h>
#include <geometry_msgs/TransformStamped.h>
#include <std_msgs/Header.h>
#include <serial/serial.h>

int main(int argc, char **argv)
{
    ros::init(argc, argv, "tf_publisher");
    ros::NodeHandle nh;
    
    std::string port;
    int baudrate;
    ros::param::param<std::string>("~port", port, "/dev/ttyUSB0");
    ros::param::param<int>("~baudrate", baudrate, 115200);
    
    serial::Serial ser(port, baudrate);
    if (!ser.isOpen())
    {
        ROS_ERROR("Failed to open serial port");
        return -1;
    }
    
    tf2_ros::TransformBroadcaster tf_broadcaster;
    geometry_msgs::TransformStamped transformStamped;
    std_msgs::Header header;
    
    while (ros::ok())
    {
        std::string line = ser.readline();
        std::istringstream ss(line);
        double x, y, qz;
        ss >> x >> y >> qz;

        header.frame_id = "odom";
        header.stamp = ros::Time::now();
        transformStamped.header = header;
        transformStamped.child_frame_id = "base_link";

        transformStamped.transform.translation.x = x;
        transformStamped.transform.translation.y = y;
        transformStamped.transform.translation.z = 0;

        transformStamped.transform.rotation.x = 0;
        transformStamped.transform.rotation.y = 0;
        transformStamped.transform.rotation.z = qz;
        transformStamped.transform.rotation.w = 0;

        tf_broadcaster.sendTransform(transformStamped);
    }

    return 0;
}
